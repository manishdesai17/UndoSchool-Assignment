package com.course.controlle;

import com.course.entity.Booking;
import com.course.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // Add Booking
    @PostMapping("/add")
    public ResponseEntity<?> addBooking(@RequestBody Booking booking) {

        bookingService.createBooking(booking);
        return ResponseEntity.ok("Booking successfully");
    }

    // Get All Bookings
    @GetMapping("/get")
    public List<Booking> getAllBookings() {

        return bookingService.getAllBookings();
    }
}