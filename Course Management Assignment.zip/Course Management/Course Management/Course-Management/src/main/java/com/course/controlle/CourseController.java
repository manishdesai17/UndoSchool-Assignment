package com.course.controlle;


import com.course.entity.Course;
import com.course.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {

    @Autowired
    private CourseService courseService;

    // Add Course with Offerings and Sessions
    @PostMapping("/add")
    public ResponseEntity<?> addCourse(@RequestBody Course course) {

        courseService.createCourse(course);
        return ResponseEntity.ok("Course add successfully");
    }

    // Get All Courses
    @GetMapping("/get")
    public List<Course> getAllCourses() {

        return courseService.getAllCourses();
    }
}