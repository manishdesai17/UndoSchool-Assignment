package com.course.controlle;

import com.course.entity.Booking;
import com.course.entity.Offering;
import com.course.entity.Parent;
import com.course.entity.Session;
import com.course.repository.BookingRepository;
import com.course.repository.OfferingRepository;
import com.course.repository.ParentRepository;
import com.course.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/parents")
public class ParentApiController {

    @Autowired
    private ParentRepository parentRepository;

    @Autowired
    private OfferingRepository offeringRepository;

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private BookingService bookingService;

    // Helper to convert session timings to parent's local timezone
    private ZonedDateTime convertToTimezone(ZonedDateTime time, String timezoneStr) {
        if (time == null) return null;
        try {
            if (timezoneStr != null && !timezoneStr.trim().isEmpty()) {
                return time.withZoneSameInstant(java.time.ZoneId.of(timezoneStr));
            }
        } catch (Exception e) {
            // Ignore and fallback
        }
        return time;
    }

    private SessionResponse mapToSessionResponse(Session session, String timezoneStr) {
        SessionResponse resp = new SessionResponse();
        resp.setId(session.getId());
        resp.setStartTime(convertToTimezone(session.getStartTime(), timezoneStr));
        resp.setEndTime(convertToTimezone(session.getEndTime(), timezoneStr));
        resp.setTeacherId(session.getTeacherId());
        return resp;
    }

    private OfferingResponse mapToOfferingResponse(Offering offering, String timezoneStr) {
        OfferingResponse resp = new OfferingResponse();
        resp.setId(offering.getId());
        resp.setOfferingName(offering.getOfferingName());
        resp.setTeacherId(offering.getTeacherId());

        List<SessionResponse> sessions = new ArrayList<>();
        if (offering.getSessions() != null) {
            for (Session session : offering.getSessions()) {
                sessions.add(mapToSessionResponse(session, timezoneStr));
            }
        }
        resp.setSessions(sessions);
        return resp;
    }

    // Get available offerings (converted to parent's timezone)
    @GetMapping("/offerings")
    public ResponseEntity<?> getAvailableOfferings(@RequestParam Long parentId) {
        try {
            Parent parent = parentRepository.findById(parentId)
                    .orElseThrow(() -> new RuntimeException("Parent not found"));
            String parentTimezone = parent.getTimezone();

            List<Offering> offerings = offeringRepository.findAll();
            List<OfferingResponse> responses = new ArrayList<>();
            for (Offering offering : offerings) {
                responses.add(mapToOfferingResponse(offering, parentTimezone));
            }
            return ResponseEntity.ok(responses);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    // Book offering
    @PostMapping("/book")
    public ResponseEntity<?> bookOffering(@RequestBody Map<String, Object> payload) {
        try {
            Long parentId = Long.valueOf(payload.get("parentId").toString());
            Long offeringId = Long.valueOf(payload.get("offeringId").toString());

            Parent parent = new Parent();
            parent.setId(parentId);

            Offering offering = new Offering();
            offering.setId(offeringId);

            Booking booking = new Booking();
            booking.setParent(parent);
            booking.setOffering(offering);

            Booking savedBooking = bookingService.createBooking(booking);
            return ResponseEntity.ok(Map.of(
                    "message", "Booking successful",
                    "bookingId", savedBooking.getId()
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    // Get parent bookings (converted to parent's timezone)
    @GetMapping("/{parentId}/bookings")
    public ResponseEntity<?> getBookings(@PathVariable Long parentId) {
        try {
            Parent parent = parentRepository.findById(parentId)
                    .orElseThrow(() -> new RuntimeException("Parent not found"));
            String parentTimezone = parent.getTimezone();

            List<Booking> bookings = bookingRepository.findByParentId(parentId);
            List<OfferingResponse> responses = new ArrayList<>();
            for (Booking booking : bookings) {
                responses.add(mapToOfferingResponse(booking.getOffering(), parentTimezone));
            }
            return ResponseEntity.ok(responses);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    // Static DTO classes for clean serialization
    public static class OfferingResponse {
        private Long id;
        private String offeringName;
        private String teacherId;
        private List<SessionResponse> sessions;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getOfferingName() { return offeringName; }
        public void setOfferingName(String offeringName) { this.offeringName = offeringName; }
        public String getTeacherId() { return teacherId; }
        public void setTeacherId(String teacherId) { this.teacherId = teacherId; }
        public List<SessionResponse> getSessions() { return sessions; }
        public void setSessions(List<SessionResponse> sessions) { this.sessions = sessions; }
    }

    public static class SessionResponse {
        private Long id;
        private ZonedDateTime startTime;
        private ZonedDateTime endTime;
        private String teacherId;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public ZonedDateTime getStartTime() { return startTime; }
        public void setStartTime(ZonedDateTime startTime) { this.startTime = startTime; }
        public ZonedDateTime getEndTime() { return endTime; }
        public void setEndTime(ZonedDateTime endTime) { this.endTime = endTime; }
        public String getTeacherId() { return teacherId; }
        public void setTeacherId(String teacherId) { this.teacherId = teacherId; }
    }
}
