package com.course.controlle;

import com.course.entity.Parent;
import com.course.service.ParentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/parent")
public class ParentController {

    @Autowired
    private ParentService parentService;

    // Add Parent
    @PostMapping("/add")
    public ResponseEntity<?> addParent(@RequestBody Parent parent) {

        parentService.createParent(parent);
        return ResponseEntity.ok("Parent add successfully");
    }
}