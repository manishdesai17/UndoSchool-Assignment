package com.course.controlle;

import com.course.entity.Offering;
import com.course.entity.Session;
import com.course.service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/teachers")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    // Create offering
    @PostMapping("/offerings")
    public ResponseEntity<?> createOffering(@RequestBody Map<String, Object> payload) {
        try {
            Long courseId = Long.valueOf(payload.get("courseId").toString());
            String offeringName = payload.get("offeringName").toString();
            String teacherId = payload.get("teacherId").toString();

            Offering offering = teacherService.createOffering(courseId, offeringName, teacherId);
            return ResponseEntity.ok(offering);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    // Add sessions to offering
    @PostMapping("/offerings/{offeringId}/sessions")
    public ResponseEntity<?> addSessions(
            @PathVariable Long offeringId,
            @RequestBody List<Session> sessions) {
        try {
            List<Session> savedSessions = teacherService.addSessionsToOffering(offeringId, sessions);
            return ResponseEntity.ok(savedSessions);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    // Get teacher offerings and sessions
    @GetMapping("/offerings")
    public ResponseEntity<List<Offering>> getTeacherOfferings(@RequestParam String teacherId) {
        List<Offering> offerings = teacherService.getTeacherOfferings(teacherId);
        return ResponseEntity.ok(offerings);
    }
}
