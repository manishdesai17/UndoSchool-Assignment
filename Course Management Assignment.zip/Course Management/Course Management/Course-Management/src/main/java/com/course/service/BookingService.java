package com.course.service;

import com.course.entity.Booking;
import com.course.entity.Offering;
import com.course.entity.Parent;
import com.course.entity.Session;
import com.course.repository.BookingRepository;
import com.course.repository.OfferingRepository;
import com.course.repository.ParentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ParentRepository parentRepository;

    @Autowired
    private OfferingRepository offeringRepository;

    // Add Booking with concurrency control and timezone-aware conflict detection
    @Transactional
    public Booking createBooking(Booking booking) {

        // Parent Validation
        if (booking.getParent() == null
                || booking.getParent().getId() == null) {
            throw new RuntimeException("Parent Id is required");
        }

        // Offering Validation
        if (booking.getOffering() == null
                || booking.getOffering().getId() == null) {
            throw new RuntimeException("Offering Id is required");
        }

        // Get Ids
        Long parentId = booking.getParent().getId();
        Long offeringId = booking.getOffering().getId();

        // Find Parent with PESSIMISTIC_WRITE lock to serialize concurrent bookings for this parent
        Parent parent = parentRepository.findByIdWithLock(parentId)
                .orElseThrow(() -> new RuntimeException("Parent not found"));

        // Find Offering with PESSIMISTIC_WRITE lock to handle concurrent booking access cleanly
        Offering newOffering = offeringRepository.findByIdWithLock(offeringId)
                .orElseThrow(() -> new RuntimeException("Offering not found"));

        // Validation: Offering must have scheduled sessions before booking
        if (newOffering.getSessions() == null || newOffering.getSessions().isEmpty()) {
            throw new RuntimeException("Cannot book an offering that has no scheduled sessions");
        }

        // Get Old Bookings
        List<Booking> oldBookings = bookingRepository.findByParentId(parentId);

        // Validation
        for (Booking oldBooking : oldBookings) {
            Offering oldOffering = oldBooking.getOffering();

            // SAME OFFERING AGAIN NOT ALLOWED
            if (oldOffering.getId().equals(newOffering.getId())) {
                throw new RuntimeException("This offering already booked");
            }

            // SAME SESSION TIMING NOT ALLOWED (Chronological instant comparison across timezones)
            for (Session oldSession : oldOffering.getSessions()) {
                for (Session newSession : newOffering.getSessions()) {

                    Instant oldStart = oldSession.getStartTime().toInstant();
                    Instant oldEnd = oldSession.getEndTime().toInstant();

                    Instant newStart = newSession.getStartTime().toInstant();
                    Instant newEnd = newSession.getEndTime().toInstant();

                    // Absolute Time Overlap Conflict: start1 < end2 && end1 > start2
                    boolean isConflict = newStart.isBefore(oldEnd) && newEnd.isAfter(oldStart);

                    if (isConflict) {
                        throw new RuntimeException("Another batch already booked at same timing");
                    }
                }
            }
        }

        // Set Data
        booking.setParent(parent);
        booking.setOffering(newOffering);

        // Save Booking
        return bookingRepository.save(booking);
    }

    // Get All Bookings
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll()
                .stream()
                .toList();
    }
}