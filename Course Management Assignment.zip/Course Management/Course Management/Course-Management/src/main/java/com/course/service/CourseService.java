package com.course.service;

import com.course.entity.Course;
import com.course.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CourseService {

    @Autowired
    private CourseRepository courseRepository;

    // Add Course
    public Course createCourse(Course course) {

        if (course.getOfferings() != null) {
            course.getOfferings().stream().forEach(offering -> {

                offering.setCourse(course);

                if (offering.getSessions() != null) {
                    offering.getSessions().stream().forEach(session -> {

                        session.setOffering(offering);
                    });
                }
            });
        }

        return courseRepository.save(course);
    }

    // Get All Courses
    public List<Course> getAllCourses() {

        return courseRepository.findAll()
                .stream()
                .toList();
    }
}