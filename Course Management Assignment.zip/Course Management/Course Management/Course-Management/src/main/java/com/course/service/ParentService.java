package com.course.service;

import com.course.entity.Parent;
import com.course.repository.ParentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ParentService {

    @Autowired
    private ParentRepository parentRepository;

    // Add Parent
    public Parent createParent(Parent parent) {

        return parentRepository.save(parent);
    }
}