package com.course.service;

import com.course.entity.Course;
import com.course.entity.Offering;
import com.course.entity.Session;
import com.course.repository.CourseRepository;
import com.course.repository.OfferingRepository;
import com.course.repository.SessionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

@Service
public class TeacherService {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private OfferingRepository offeringRepository;

    @Autowired
    private SessionRepository sessionRepository;

    // Create a new offering/section under a course
    @Transactional
    public Offering createOffering(Long courseId, String offeringName, String teacherId) {
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        Offering offering = new Offering();
        offering.setOfferingName(offeringName);
        offering.setCourse(course);
        offering.setTeacherId(teacherId);

        return offeringRepository.save(offering);
    }

    // Add sessions to an existing offering and prevent teacher double-booking
    @Transactional
    public List<Session> addSessionsToOffering(Long offeringId, List<Session> sessions) {
        Offering offering = offeringRepository.findById(offeringId)
                .orElseThrow(() -> new RuntimeException("Offering not found"));

        String teacherId = offering.getTeacherId();

        // Retrieve all existing sessions for this teacher
        List<Session> teacherSessions = sessionRepository.findByTeacherId(teacherId);

        for (Session newSession : sessions) {
            Instant newStart = newSession.getStartTime().toInstant();
            Instant newEnd = newSession.getEndTime().toInstant();

            if (newStart.isAfter(newEnd) || newStart.equals(newEnd)) {
                throw new RuntimeException("Session start time must be before end time");
            }

            // Check overlap with teacher's other classes
            for (Session oldSession : teacherSessions) {
                Instant oldStart = oldSession.getStartTime().toInstant();
                Instant oldEnd = oldSession.getEndTime().toInstant();

                boolean isConflict = newStart.isBefore(oldEnd) && newEnd.isAfter(oldStart);
                if (isConflict) {
                    throw new RuntimeException("Teacher " + teacherId + " is already scheduled to teach another class at this time: "
                            + oldSession.getStartTime() + " to " + oldSession.getEndTime());
                }
            }

            // Check overlap with other new sessions in the same request batch
            for (Session otherNewSession : sessions) {
                if (otherNewSession == newSession) continue;
                Instant otherStart = otherNewSession.getStartTime().toInstant();
                Instant otherEnd = otherNewSession.getEndTime().toInstant();

                if (newStart.isBefore(otherEnd) && newEnd.isAfter(otherStart)) {
                    throw new RuntimeException("Multiple sessions in this request overlap with each other");
                }
            }

            // Link to offering and teacher
            newSession.setOffering(offering);
            newSession.setTeacherId(teacherId);
        }

        return sessionRepository.saveAll(sessions);
    }

    // View upcoming offerings and sessions for a teacher
    public List<Offering> getTeacherOfferings(String teacherId) {
        return offeringRepository.findByTeacherId(teacherId);
    }
}
